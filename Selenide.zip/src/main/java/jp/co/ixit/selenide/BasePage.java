package jp.co.ixit.selenide;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.withText;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import lombok.extern.slf4j.Slf4j;

/**
 * Basic function base.
 * 
 * @author Okazaki
 */
@Slf4j
public class BasePage {
	
	protected static void classTextClick(String classname, String test) {
		
		ElementsCollection elementsCollection = $$(By.className(classname));
		for (WebElement e : elementsCollection) {
			log.info("collection e2 ??? [" + test + "[" + e.getText() + "]]");
			if (e.getText().equals(test)) {
				log.info("collectionClick e2 [" + e.getText() + "[" + e + "]]");
				e.click();
				e.click();
				e.click();
			}
		}
	}

	protected static void displayedElementClick(String examName) {
		
		examName = examName.trim();

		if (!examName.isEmpty()) {
			$("body").shouldHave(text(examName)); // 指定の文字列が表示されるまで待つ
			ElementsCollection elementsCollection = $$(withText(examName));
			for (WebElement e : elementsCollection) {
				if (e.isDisplayed() == true) {
					Selenide.executeJavaScript("arguments[0].scrollIntoView(true);", e);
					Selenide.executeJavaScript("javascript:window.scrollBy(0,-80)");
					e.click();
				}
			}
		}
		
	}

	protected static void elementClick(String examName) {
		elementClick(examName, 0);
	}

	protected static void elementClick(String examName, int i) {
		
		examName = examName.trim();

		// $(withText(examName),i).scrollTo();

		WebElement element = $(withText(examName), i);

		Selenide.executeJavaScript("arguments[0].scrollIntoView(true);", element);
		Selenide.executeJavaScript("javascript:window.scrollBy(0,-80)");
		$(withText(examName), i).click();

	}

	protected static String getNoKana(int iNo) {
		
		String sTemp = String.format("%06d", iNo);
		sTemp = sTemp.replaceAll("0", "ア");
		sTemp = sTemp.replaceAll("1", "イ");
		sTemp = sTemp.replaceAll("2", "ウ");
		sTemp = sTemp.replaceAll("3", "エ");
		sTemp = sTemp.replaceAll("4", "オ");
		sTemp = sTemp.replaceAll("5", "カ");
		sTemp = sTemp.replaceAll("6", "キ");
		sTemp = sTemp.replaceAll("7", "ク");
		sTemp = sTemp.replaceAll("8", "ケ");
		sTemp = sTemp.replaceAll("9", "コ");
		return sTemp;

	}

	protected static void moveView(String text) {
		log.info("moveView1[" + text + "]");
		WebElement element1 = $(withText(text));
		log.info("element1[" + element1 + "]");
		Selenide.executeJavaScript("arguments[0].scrollIntoView(true);", element1);
		log.info("moveView1[" + text + "]");
		Selenide.executeJavaScript("javascript:window.scrollBy(0,-80)");
		log.info("moveView2");
	}

	protected static void moveViewByClass(String classNmae) {

		WebElement element1 = $(By.className(classNmae));
		Selenide.executeJavaScript("arguments[0].scrollIntoView(true);", element1);
		Selenide.executeJavaScript("javascript:window.scrollBy(0,-80)");
		
	}

	protected static void setDisplayedSelect(String value) {
		
		ElementsCollection elementsCollection = $$("select");
		for (SelenideElement e : elementsCollection) {
			if (e.isDisplayed() == true) {
				e.selectOption(value);
			}
		}
		
	}

	protected static void sleep(int i) {

		try {
			Thread.sleep(i); // ミリ秒Sleepする
			log.info("sleep[" + i + "]");
		} catch (InterruptedException e) {

		}

	}

	public BasePage() {
		super();
	}

}