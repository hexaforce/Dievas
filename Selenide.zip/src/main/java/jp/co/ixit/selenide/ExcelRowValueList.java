package jp.co.ixit.selenide;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import lombok.Data;

/**
 * Excel loader.
 * 
 * @author Okazaki
 *
 */
@Data
public class ExcelRowValueList {

	private final List<String> headerList;
	private final List<Map<String, String>> valueRowList;

	public ExcelRowValueList(InputStream excelInputStream) {
		this.headerList = new ArrayList<>();
		this.valueRowList = new ArrayList<>();

		// 全セルを取得
		try {
			Workbook workbook = WorkbookFactory.create(excelInputStream);
			for (Sheet sheet : workbook) {
				int i = 0;
				for (Row row : sheet) {
					if (i == 0)
						for (Cell cell : row)
							headerList.add(getCellValue(cell).toString());
					else {
						int j = 0;
						Map<String, String> rowValues = new HashMap<>();
						for (Cell cell : row) {
							rowValues.put(headerList.get(j), getCellValue(cell).toString());
							j++;
						}
						valueRowList.add(rowValues);
					}
					i++;
				}
			}
			workbook.close();
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
	}

	private static Object getCellValue(Cell cell) {
		switch (cell.getCellTypeEnum()) {
		case BLANK:
			return "";
		case BOOLEAN:
			return cell.getBooleanCellValue();
		case ERROR:
			return null;
		case FORMULA:
			return cell.getCellFormula();
		case NUMERIC:
			if (DateUtil.isCellDateFormatted(cell))
				return cell.getDateCellValue();
			else
				return (int) cell.getNumericCellValue(); // intに変換しています
		case STRING:
			return cell.getRichStringCellValue().getString();
		case _NONE:
			return "";
		default:
			return "";
		}
	}

}
