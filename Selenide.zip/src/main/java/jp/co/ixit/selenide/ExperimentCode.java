//package jp.co.ixit.selenide;
//
//import org.junit.jupiter.api.AfterAll;
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.Test;
//import org.junit.platform.runner.JUnitPlatform;
//import org.junit.runner.RunWith;
//
//import com.codeborne.selenide.Configuration;
//import com.codeborne.selenide.WebDriverRunner;
//
//import jp.co.ixit.selenide.form_view.*;
//import jp.co.ixit.selenide.particle_step.*;
//
///**
// * For debugging.
// * 
// * @author Okazaki
// */
//@RunWith(JUnitPlatform.class)
//public class ExperimentCode {
//
//	final static String DRIVER_PATH = System.getProperty("user.dir") + "\\chromedriver.exe";
//	
//    @BeforeAll
//	public static void setUpClass() {
//		Configuration.timeout = 20000; // タイムアウトの時間を10000ミリ秒にする(デフォルト:4000ミリ秒)
//		Configuration.browser = WebDriverRunner.CHROME;
//		System.setProperty("webdriver.chrome.driver", DRIVER_PATH);
//	}
//
//	@Test
//	public void 一般入試_100001() {
//		MyPageLogin.でログインする("bunkyo.opt+na100000@gmail.com", "Test1234");
//		MyPageHome.で出願を進める();
//
//		Step1.で試験区分を選択("ＡＯ入試");
//		Step2.で試験を選択("ＡＯ入試 プレゼンテーション型２期", "2017年12月10日", "ＡＯ入試 プレゼンテーション型 ２期 情報学部情報システム学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("ＡＯ入試");
//		Step2.で試験を選択("ＡＯ入試 資格優先型前期", "2017年9月16日", "ＡＯ入試 資格優先型 前期 文学部 英米語英米文学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("ＡＯ入試");
//		Step2.で試験を選択("ＡＯ入試 文教大学同窓１期", "2017年10月15日", "ＡＯ入試 文教大学同窓 １期 情報学部 情報システム学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("ＡＯ入試");
//		Step2.で試験を選択("ＡＯ入試 ビジネスキャリアⅠーＡ", "2017年9月17日", "ＡＯ入試 ビジネスキャリアⅠーＡ 経営学部 経営学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("特別入試");
//		Step2.で試験を選択("帰国生入試", "2017年11月19日", "帰国生入試 情報学部 情報システム学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("特別入試");
//		Step2.で試験を選択("外国人留学生入試１期", "2017年11月18日", "外国人留学生入試１期 文学部 日本語日本文学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("特別入試");
//		Step2.で試験を選択("外国人留学生入試２期", "2018年2月26日", "外国人留学生入試２期 情報学部 情報システム学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("編入学試験");
//		Step2.で試験を選択("一般編入学試験", "2018年2月10日", "一般編入学試験 人間科学部 人間科学科 現代文化コース");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("大学院入試");
//		Step2.で試験を選択("大学院入試１期", "2017年9月9日", "人間科学研究科 臨床心理学専攻 修士課程 一般入学選考");
//
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("大学院入試");
//		// Step2.で試験を選択("大学院入試２期","2017年11月11日","言語文化研究科 言語文化専攻 修士課程 地域言語文化研究コース
//		// 一般入学選考");
//
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("ＡＯ入試");
//		Step2.で試験を選択("ＡＯ入試 3月入試", "2018年3月6日", "ＡＯ入試 ３月入試 情報学部 情報社会学科");
//		Step2_1.で繰り返し();
//		Step1.で試験区分を選択("大学院入試");
//		Step2.で試験を選択("大学院入試３期", "2018年2月24日", "言語文化研究科 言語文化専攻 修士課程 地域言語文化研究コース一般入学選考");
//		// Step2_1.で繰り返し();
//
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("全国入試", "2018年2月1日", "全国入試 教育学部 学校教育課程 国語専修");
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("Ａ日程入試１期", "2018年2月7日", "Ａ日程入試 １期 教育学部 学校教育課程 国語専修");
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("Ａ日程入試１期", "2018年2月8日", "Ａ日程入試 １期 教育学部 学校教育課程 国語専修");
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("Ａ日程入試１期", "2018年2月9日", "Ａ日程入試 １期 教育学部 学校教育課程 国語専修");
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("センター試験利用入試１期", "大学入試センター試験利用入試", "大学入試センター試験利用入試 １期 教育学部
//		// 国語専修");
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("センター試験利用入試２期", "大学入試センター試験利用入試", "大学入試センター試験利用入試 ２期
//		// 文学部日本語日本文学科");
//		// Step2_1.で繰り返し();
//		// Step1.で試験区分を選択("一般入試");
//		// Step2.で試験を選択("センター試験利用入試３期", "大学入試センター試験利用入試", "大学入試センター試験利用入試 ３期 教育学部国語専修");
//
//		Step2_2.で進む();
//		Step3.でテストデータ入力("国際学研究科 国際学専攻 修士課程 学内入学選考");
//		Step4.で次へ();
//		Step5.でカード決済で次へ();
//		Step6.で出願情報確定();
//		$("body").shouldHave(text("出願申込完了"));
//	}
//	
//    @AfterEach
//	public void tearDown() {
//    	
//	}
//
//    @AfterAll
//	public static void tearDownClass() {
//		WebDriverRunner.closeWebDriver();
//	}
//    
//}
