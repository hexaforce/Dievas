package jp.co.ixit.selenide;

import static java.lang.System.*;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import org.apache.commons.io.FileUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

/**
 * Velocity template merge.
 * 
 * @author Okazaki
 */
public class ReadExcelTest {

	static final String INPUT_DIR = System.getProperty("user.dir") + "\\src\\main\\resources\\velocity";
	static final String FILE_NAME = "testNennai.vm";
	
	static final String INPUT_DIR_TEST_DATA = System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\";
	static final String FILE_NAME_EXCEL = "testNennai.xlsx";
	
	static final String OUTPUT_DIR_TEST_CASE = System.getProperty("user.dir") + "\\src\\test\\java\\jp\\co\\ixit\\selenide\\";
	static final String JAVA_NAME = "testNennaiTest";
	
	private static String mergeText(String templatefileName, ExcelRowValueList rowValueList) {
		StringWriter writer = new StringWriter();
		Velocity.setProperty(Velocity.FILE_RESOURCE_LOADER_PATH, INPUT_DIR);
		Velocity.init();
		VelocityContext context = new VelocityContext();
		context.put("ExcelRowValueList", rowValueList);
		
		Template template = Velocity.getTemplate(FILE_NAME, "utf-8");
		template.merge(context, writer);
		return writer.toString();
	}

	/**
	 * Create account.
	 * 
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		File velocity = new File(INPUT_DIR +"\\"+ FILE_NAME);
		if (!velocity.exists()) {
			out.println("not found velocity : " + velocity.getAbsolutePath());
			System.exit(0);
		}
		
		File excel = new File(INPUT_DIR_TEST_DATA + FILE_NAME_EXCEL);
		if (!excel.exists()) {
			out.println("not found excel : " + excel.getAbsolutePath());
			System.exit(0);
		}
		
		out.println(new ReadExcelTest().execute(velocity, excel));
		
	}
	
	public String execute(File velocity, File excel) throws IOException {
		
		InputStream excelInputStream = FileUtils.openInputStream(excel);
		
		if (excelInputStream == null) {
			throw new IOException("not read excel : " + excel.getAbsolutePath());
		}
		
		ExcelRowValueList rowValueList = new ExcelRowValueList(excelInputStream);
		
		String javaCode = mergeText(FILE_NAME, rowValueList);
		
		javaCode = javaCode.replace("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )", JAVA_NAME);
		
		FileUtils.writeStringToFile(new File(OUTPUT_DIR_TEST_CASE + JAVA_NAME+".java"), javaCode, "UTF-8");
		
		return "テストクラス(" + JAVA_NAME + ")を作成しました。";
		
	}

}
