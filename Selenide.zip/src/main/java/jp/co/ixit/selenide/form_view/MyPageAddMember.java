package jp.co.ixit.selenide.form_view;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.withText;
import static com.codeborne.selenide.Selenide.$;

import org.openqa.selenium.By;

import com.codeborne.selenide.Selenide;

import jp.co.ixit.selenide.BasePage;

/**
 * Sending mail address.
 * 
 * @author Okazaki
 */
public class MyPageAddMember extends BasePage {
	// private static final String URL =
	// "https://freude-entry-test.dev-campus-gate.com/register";
	private static final String URL = "https://st-bunkyo.dev-campus-gate.com/register";
	// private static final String URL = "http://localhost:58080/register";

	public static void でメールアドレス送信(String mailAddress) {

		Selenide.open(URL);
		$(withText("同意する")).click();

		Selenide.$(By.id("email")).setValue(mailAddress);
		Selenide.$(By.id("emailConfirm")).setValue(mailAddress);

		$("button").click(); // 送信ボタン
		$("body").shouldHave(text("確認メールの送信"));
	}

}
