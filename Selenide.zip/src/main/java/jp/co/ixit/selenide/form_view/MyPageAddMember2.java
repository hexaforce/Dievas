package jp.co.ixit.selenide.form_view;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import org.openqa.selenium.By;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

/**
 * MyPage entry.
 * 
 * @author Okazaki
 *
 */
public class MyPageAddMember2 {

	private static SelenideElement setValue;

	public static void で登録(String sUrl) {

		Selenide.open(sUrl);

		Selenide.$(By.id("password")).setValue("Test1234");
		Selenide.$(By.id("passwordConfirm")).setValue("Test1234");

		$("button").click(); // 送信ボタン
		$("body").shouldHave(text("マイページ登録完了"));

	}

}
