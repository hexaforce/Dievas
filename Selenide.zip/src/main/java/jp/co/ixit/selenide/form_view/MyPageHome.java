package jp.co.ixit.selenide.form_view;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import org.openqa.selenium.By;

import jp.co.ixit.selenide.BasePage;

/**
 * Entrance examination application.
 * 
 * @author Okazaki
 */
public class MyPageHome extends BasePage {

	public static void で出願を進める() {

		// elementClick("出願を進める");
		$(By.className("confirmination-dialog")).click();

		// $(withText("了承する")).click();
		sleep(100);
		moveView("了承する");
		$("body").shouldHave(text("了承する"));

		// $(By.className("agree-label")).click(); //了承する

		sleep(200);
		$("input[id=agree]").click();

		$(By.className("btn-danger")).click(); // 次に進む
		// $("input[id=nextAnchor]").click();

	}

}
