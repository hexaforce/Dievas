package jp.co.ixit.selenide.form_view;

import org.openqa.selenium.By;

import com.codeborne.selenide.Selenide;

/**
 * Login action.
 * 
 * @author Okazaki
 */
public class MyPageLogin {
	// private static final String URL =
	// "https://freude-entry-test.dev-campus-gate.com/login";
	private static final String URL = "https://st-bunkyo.dev-campus-gate.com/login";
	// private static final String URL = "http://localhost:58080/login";

	public static void open() {
		Selenide.open(URL);
	}

	public static String title() {
		return Selenide.title();
	}

	public static void でログインする() {
		Selenide.$(By.tagName("button")).click();
	}

	public static void でログインする(String mailAddress, String password) {
		open();
		メールアドレスは(mailAddress);
		パスワードは(password);

		Selenide.$(By.tagName("button")).click();
	}

	public static void パスワードは(String password) {
		Selenide.$(By.id("password")).setValue(password);
	}

	public static void メールアドレスは(String mailAddress) {
		Selenide.$(By.id("email")).setValue(mailAddress);
	}

}
