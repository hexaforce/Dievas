package jp.co.ixit.selenide.form_view;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.withText;
import static com.codeborne.selenide.Selenide.$;

import java.io.File;
import java.util.Random;

import jp.co.ixit.selenide.BasePage;

/**
 * Profile input.
 * 
 * @author Okazaki
 *
 */
public class MyPageUser extends BasePage {

	public static void でテストデータ入力(String lastNameKanji, String firstNameKanji, String lastNameKana, String firstNameKana,
			String highSchool01, String highSchool02, String highSchool03) {

		$(withText("登録・変更する")).click();

		$("body").shouldHave(text("個人情報登録"));

		$("input[name=lastName]").setValue(lastNameKanji); // 漢字姓 2は0から数えて何番目かの数
		$("input[name=firstName]").setValue(firstNameKanji); // 漢字名

		$("input[name=lastNameKana]").setValue(lastNameKana); // カナ姓
		$("input[name=firstNameKana]").setValue(firstNameKana); // カナ名

		$(withText("男")).click();

		Random rnd = new Random();
		$("select[name=birthdayYear]").selectOption(String.valueOf(rnd.nextInt(9) + 1990)); // 誕生日
		$("select[name=birthdayMonth]").selectOption(String.valueOf(rnd.nextInt(12) + 1)); // 誕生日
		$("select[name=birthdayDay]").selectOption(String.valueOf(rnd.nextInt(28) + 1)); // 誕生日

		$("input[name=postcode]").setValue("2750001"); // 郵便番号

		$(withText("郵便番号から住所を探す")).click();

		$("input[name=townArea]").setValue("ちょうばんち"); // 丁目番地

		$("input[name=phone]").setValue("044-1234-5678"); // 電話番号
		$("input[name=mobilePhone]").setValue("080-1234-5678"); // 携帯電話

		// 出身校
		BasePage.elementClick("高校検索 「高等学校・中等教育学校の方はこちらをクリック」");

		if (highSchool03.equals("文教大学付属") == true) {
			$("input[id=highSchoolSearchFreeWord]").setValue("13618C");
			$(withText("13618C 文教大学付属 高等学校")).click();
			$(withText("13618C 文教大学付属 高等学校")).click();

		} else {
			$("select[id=highSchoolSearchPrefectureCode]").selectOption(highSchool01); // 都道府県
			$("select[id=highSchoolSearchEstablishCode]").selectOption(highSchool02); // 設置区分
			$(withText(highSchool03)).click();
		}
		$("select[name=highSchoolCourseCode]").selectOption("1.全日制"); // 課程
		$("select[name=highSchoolBranchCode]").selectOption("01.普通・理数"); // 学科区分

		$("select[name=highSchoolGraduatedYear]").selectOption("2018"); // 卒業 年
		$("select[name=highSchoolGraduatedMonth]").selectOption("3"); // 卒業 月

		$(withText("変更する")).click();

		// --------写真
		$(withText("写真をアップロードする")).click();

		$("input[name=file]").uploadFile(new File("C:\\Users\\admin\\Pictures\\Sample Pictures\\Penguins.jpg"));

		$("button[id=profileImgZoomDown]").click(); // 縮小
		$("button[id=profileImgZoomDown]").click(); // 縮小

		$(withText("アップロード"), 1).click();
		$(withText("マイページへ"), 1).click();

	}

}
