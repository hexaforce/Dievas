package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step1_2 extends BasePage {

	public static void で試験区分を選択(String examName) {
		// if() {
		$("body").shouldHave(text("出願する入試の試験日を選択してください。"));
		elementClick(examName);
		// }

	}

}
