package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import org.openqa.selenium.By;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step2 extends BasePage {

	public static void で試験を選択(String examName1, String examName2, String examName3, String examName4,
			String examName5) {

		$("body").shouldHave(text("出願する入試種別を選択してください。"));
		$(By.linkText(examName1)).click();

		$("body").shouldHave(text("出願する入試の試験日を選択してください。"));
		$(By.linkText(examName2)).click();

		$("body").shouldHave(text("出願する入試の学部・学科を選択してください。"));

		if (examName3.contains("*ABC選択者")) {
			$("input[id=MusicDepartment]").click(); // 音楽専修をクリック
			sleep(200);
			$("select[id=musicExamSelect]").selectOption("ABC選択(声楽)");

		} else if (examName3.contains("*ABD選択者")) {
			$("input[id=MusicDepartment]").click(); // 音楽専修をクリック
			sleep(200);
			$("select[id=musicExamSelect]").selectOption("ABD選択(管弦打楽器)");

		} else {
			classTextClick("ng-binding", examName3);
		}
		sleep(200);

		// 受験会場
		if (!examName4.isEmpty()) {
			$("select[id=siteExamSelect]").click();
			$("select[id=siteExamSelect]").selectOption(examName4);
			$("select[id=siteExamSelect]").click();
		}

		// 選択科目
		if (!examName5.isEmpty()) {
			$("select[id=subjectExamSelect]").click();

			$("select[id=subjectExamSelect]").selectOption(examName5);

			$("select[id=subjectExamSelect]").click();
		}
		sleep(500);
		elementClick("次へ");
		// sleep(500);
		// elementClick("次へ");

		$("body").shouldHave(text("以下の志望内容に間違いがないかを、ご確認ください。"));
		elementClick("次へ進む");
		sleep(500);
		$(By.className("btn-danger")).click();

	}

}
