package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step2_2 extends BasePage {

	public static void で進む() {

		$("body").shouldHave(text("以下の志望内容に間違いがないかを、ご確認ください。"));
		elementClick("次へ進む");
		elementClick("次へ進む");
	}

}