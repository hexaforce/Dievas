package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step3 extends BasePage {

	public static void でテストデータ入力() {

		$("body").shouldHave(text("以下の内容を入力または確認してください"));

		elementClick("次へ進む");

	}

}
