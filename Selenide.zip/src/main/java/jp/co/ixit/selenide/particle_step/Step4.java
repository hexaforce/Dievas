package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step4 extends BasePage {

	public static void で次へ() {

		$("body").shouldHave(text("登録内容の確認"));
		elementClick("次へ進む");

	}

}
