package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Selenide.$;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step5 extends BasePage {

	public static void でカード決済で次へ() {
		elementClick("VISA");

		$("input[name=paymentCardNo]").setValue("4111111111111111"); // クレジット番号（ハイフンなしで半角数字）

		$("select[name=paymentLimitMonth]").selectOption("12"); // 有効期限
		$("select[name=paymentLimitYear]").selectOption("28"); // 有効期限

		$("input[name=paymentCardOwner]").setValue("TEST AAAA"); // カード名義人
		$("input[name=paymentSecuCd]").setValue("123"); // セキュリティコード

		elementClick("次へ進む");

	}

}
