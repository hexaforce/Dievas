package jp.co.ixit.selenide.particle_step;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import org.openqa.selenium.By;

import jp.co.ixit.selenide.BasePage;

/**
 * Step macro action.
 * 
 * @author Okazaki
 */
public class Step6 extends BasePage {

	public static void で出願情報確定() {

		$("body").shouldHave(text("出願情報確定"));

		moveView("BUNKYO");

		$(By.className("bt_red")).click();

	}

}
