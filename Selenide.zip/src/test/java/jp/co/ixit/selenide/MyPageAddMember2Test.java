package jp.co.ixit.selenide;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;

import jp.co.ixit.selenide.form_view.MyPageAddMember2;

/**
 * Selenide test case.
 * 
 * @author Okazaki
 */
@RunWith(JUnitPlatform.class)
public class MyPageAddMember2Test {

	final static String DRIVER_PATH_CHROME = System.getProperty("user.dir") + "\\chromedriver.exe";
	final static String DRIVER_PATH_IE = System.getProperty("user.dir") + "\\IEDriverServer.exe";
	final static String DRIVER_PATH_SAFARI = System.getProperty("user.dir") + "\\SafariDriver.exe";
	
    @BeforeAll
    static void initAll() {
		System.setProperty("webdriver.chrome.driver", DRIVER_PATH_CHROME);
		System.setProperty("webdriver.ie.driver", DRIVER_PATH_IE);
		System.setProperty("webdriver.safari.driver", DRIVER_PATH_SAFARI);
		
		Configuration.browser = WebDriverRunner.CHROME;
		Configuration.timeout = 10000;
    }

    @BeforeEach
    void init() {
//      File classpathRoot = new File(System.getProperty("user.dir"));
//      DesiredCapabilities capabilities = new DesiredCapabilities();
//      capabilities.setCapability("deviceName", "Android Emulator");
//      capabilities.setCapability("platformVersion", "4.4");
//      capabilities.setCapability("appPackage", "com.example.android.contactmanager");
//      capabilities.setCapability("appActivity", ".ContactManager");
//      driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
//      WebDriverRunner.setWebDriver(driver);
    }

	
		@Test
	    public void メンバー追加_100182() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P9YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100183() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P10YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100184() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P11YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100185() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P12YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100186() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P13YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100187() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P14YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100188() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P15YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100189() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P16YKWnbzFtNoYmBVmT"); 
	    }    
	
		@Test
	    public void メンバー追加_100190() {
	    	MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/E8P17YKWnbzFtNoYmBVmT"); 
	    }    

    @AfterEach
    void tearDown() {
    	
    }

    @AfterAll
    static void tearDownAll() {
    	WebDriverRunner.closeWebDriver();
    }

}