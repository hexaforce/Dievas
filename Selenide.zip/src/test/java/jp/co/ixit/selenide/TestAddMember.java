package jp.co.ixit.selenide;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;

import jp.co.ixit.selenide.form_view.MyPageAddMember;

/**
 * This test is ignore.
 * 
 * @author Okazaki
 */
public class TestAddMember {
	
	final static String DRIVER_PATH = System.getProperty("user.dir") + "\\chromedriver.exe";
	
    @BeforeAll
    static void initAll() {
		Configuration.browser = WebDriverRunner.CHROME;
		Configuration.timeout = 10000;
		System.setProperty("webdriver.chrome.driver", DRIVER_PATH);
    }

    @BeforeEach
    void init() {
    	
    }

	@Test
	@DisplayName("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )")
	public void メンバー追加_100182() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00181@gmail.com");
	}

	@Test
	@DisplayName("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )")
	public void メンバー追加_100183() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00184@gmail.com");
	}

	@Test
	@DisplayName("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )")
	public void メンバー追加_100184() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00185@gmail.com");
	}

	@Test
	public void メンバー追加_100185() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00186@gmail.com");
	}

	@Test
	public void メンバー追加_100186() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00187@gmail.com");
	}

	@Test
	@DisplayName("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )")
	public void メンバー追加_100187() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00188@gmail.com");
	}

	@Test
	@DisplayName("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )")
	public void メンバー追加_100188() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00189@gmail.com");
	}

	@Test
	@DisplayName("( ๑❛ᴗ❛๑)۶♡٩(๑❛ᴗ❛๑ )")
	public void メンバー追加_100189() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00190@gmail.com");
	}

	@Test
	public void メンバー追加_100190() {
		MyPageAddMember.でメールアドレス送信("bunkyo.opt+Ippan00191@gmail.com");
	}

    @AfterEach
    void tearDown() {
    	
    }

    @AfterAll
    static void tearDownAll() {
		WebDriverRunner.closeWebDriver();
    }
	
}
