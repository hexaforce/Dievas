package jp.co.ixit.selenide;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;

import jp.co.ixit.selenide.form_view.MyPageAddMember2;

/**
 * This test is ignore.
 * 
 * @author Okazaki
 */
public class TestAddMember2 {

	final static String DRIVER_PATH = System.getProperty("user.dir") + "\\chromedriver.exe";
	
    @BeforeAll
    static void initAll() {
		Configuration.browser = WebDriverRunner.CHROME;
		Configuration.timeout = 10000;
		System.setProperty("webdriver.chrome.driver", DRIVER_PATH);
    }

    @BeforeEach
    void init() {
    	
    }

	@Test
	@DisplayName("╯°□°）╯")
	public void メンバー追加_100000() {
		MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/hmltL6eKgaqjc1Rwrpvb");
	}

	@Test
	public void メンバー追加_100001() {
		MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/kLQRE45zgqDzGRotiLvR");
	}

	@Test
	public void メンバー追加_100002() {
		MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/5VOfFGFXhUfxEa5jqG1F");
	}

	@Test
	public void メンバー追加_100003() {
		MyPageAddMember2.で登録("https://st-bunkyo.dev-campus-gate.com/password/set/Ft85rgFysfP1D9kOw7Jm");
	}

    @AfterEach
    void tearDown() {
    	
    }

    @AfterAll
    static void tearDownAll() {
    	WebDriverRunner.closeWebDriver();
    }

}