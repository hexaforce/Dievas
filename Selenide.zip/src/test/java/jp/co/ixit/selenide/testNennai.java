package jp.co.ixit.selenide;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;

import jp.co.ixit.selenide.form_view.MyPageHome;
import jp.co.ixit.selenide.form_view.MyPageLogin;
import jp.co.ixit.selenide.particle_step.Step1;
import jp.co.ixit.selenide.particle_step.Step2;
import jp.co.ixit.selenide.particle_step.Step3;
import jp.co.ixit.selenide.particle_step.Step4;
import jp.co.ixit.selenide.particle_step.Step5;
import jp.co.ixit.selenide.particle_step.Step6;

/**
 * None have runner.
 * 
 * @author Okazaki
 */
public class testNennai {

	@BeforeAll
	public static void setUpClass() {
		Configuration.timeout = 10000; // タイムアウトの時間を10000ミリ秒にする(デフォルト:4000ミリ秒)
		Configuration.browser = WebDriverRunner.CHROME;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\chromedriver_win32\\chromedriver.exe");
	}

    @BeforeEach
    void init() {
    	
    }
	
	@Test
	@DisplayName("（＾＾＃）")
	public void 一般入試_100178() {
		MyPageLogin.でログインする("bunkyo.opt+Ippan00179@gmail.com", "Test1234");
		MyPageHome.で出願を進める();
		Step1.で試験区分を選択("一般");

		Step2.で試験を選択("全国入試", "2018年2月1日", "全国入試　経営学部　経営学科", "福岡会場", "政治・経済");
		Step3.でテストデータ入力();
		Step4.で次へ();
		Step5.でカード決済で次へ();
		Step6.で出願情報確定();
		$("body").shouldHave(text("出願申込完了"));
	}

	@Test
	public void 一般入試_100179() {
		MyPageLogin.でログインする("bunkyo.opt+Ippan00180@gmail.com", "Test1234");
		MyPageHome.で出願を進める();
		Step1.で試験区分を選択("一般");

		Step2.で試験を選択("全国入試", "2018年2月1日", "全国入試　経営学部　経営学科", "那覇会場", "数学Ⅰ・数学Ａ");
		Step3.でテストデータ入力();
		Step4.で次へ();
		Step5.でカード決済で次へ();
		Step6.で出願情報確定();
		$("body").shouldHave(text("出願申込完了"));
	}

	@Test
	public void 一般入試_100180() {
		MyPageLogin.でログインする("bunkyo.opt+Ippan00181@gmail.com", "Test1234");
		MyPageHome.で出願を進める();
		Step1.で試験区分を選択("一般");

		Step2.で試験を選択("全国入試", "2018年2月1日", "全国入試　経営学部　経営学科", "札幌会場", "生物基礎・生物");
		Step3.でテストデータ入力();
		Step4.で次へ();
		Step5.でカード決済で次へ();
		Step6.で出願情報確定();
		$("body").shouldHave(text("出願申込完了"));
	}

	@Test
	public void 一般入試_100181() {
		MyPageLogin.でログインする("bunkyo.opt+Ippan00182@gmail.com", "Test1234");
		MyPageHome.で出願を進める();
		Step1.で試験区分を選択("一般");

		Step2.で試験を選択("全国入試", "2018年2月1日", "全国入試　経営学部　経営学科", "盛岡会場", "化学基礎・化学");
		Step3.でテストデータ入力();
		Step4.で次へ();
		Step5.でカード決済で次へ();
		Step6.で出願情報確定();
		$("body").shouldHave(text("出願申込完了"));
	}

    @AfterEach
    void tearDown() {
    	
    }

	@AfterAll
	public static void tearDownClass() {
		WebDriverRunner.closeWebDriver();
	}

}
