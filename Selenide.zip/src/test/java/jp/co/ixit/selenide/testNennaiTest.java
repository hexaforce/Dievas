package jp.co.ixit.selenide;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;

import jp.co.ixit.selenide.form_view.MyPageHome;
import jp.co.ixit.selenide.form_view.MyPageLogin;
import jp.co.ixit.selenide.particle_step.Step1;
import jp.co.ixit.selenide.particle_step.Step2;
import jp.co.ixit.selenide.particle_step.Step3;
import jp.co.ixit.selenide.particle_step.Step4;
import jp.co.ixit.selenide.particle_step.Step5;
import jp.co.ixit.selenide.particle_step.Step6;

/**
 * Selenide test case.
 * 
 * @author Okazaki
 */
@RunWith(JUnitPlatform.class)
public class testNennaiTest {

	@BeforeAll
	public static void setUpClass() {
		Configuration.timeout = 10000; // タイムアウトの時間を10000ミリ秒にする(デフォルト:4000ミリ秒)
		Configuration.browser = WebDriverRunner.CHROME;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\chromedriver_win32\\chromedriver.exe");
	}

    @BeforeEach
    void init() {
    	
    }
	
	    @Test
	    public void 一般入試_100182() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00183@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","越谷校舎","世界史Ｂ");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100183() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00184@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","湘南校舎","日本史Ｂ");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100184() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00185@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","東京会場","地理Ｂ");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100185() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00186@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","越谷校舎","政治経済");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100186() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00187@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","湘南校舎","数学Ⅰ・数学Ａ");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100187() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00188@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","東京会場","数学Ⅰ・数学Ⅱ・数学Ａ・数学Ｂ");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100188() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00189@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","越谷校舎","生物基礎・生物");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100189() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00190@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","湘南校舎","物理基礎・物理");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }
	    @Test
	    public void 一般入試_100190() {
	        MyPageLogin.でログインする("bunkyo.opt+Ippan00191@gmail.com","Test1234");
	        MyPageHome.で出願を進める();
	        Step1.で試験区分を選択("一般");
	        
	        Step2.で試験を選択("A日程入試1期","2018年2月7日","Ａ日程入試　１期　教育学部　学校教育課程　国語専修","東京会場","世界史Ｂ");				
	        Step3.でテストデータ入力();
	        Step4.で次へ();
	        Step5.でカード決済で次へ();
	        Step6.で出願情報確定();
	        $("body").shouldHave(text("出願申込完了"));
	    }

    @AfterEach
    void tearDown() {
    	
    }

	@AfterAll
	public static void tearDownClass() {
		WebDriverRunner.closeWebDriver();
	}

}
