package jp.co.ixit.selenide;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;

import jp.co.ixit.selenide.form_view.MyPageLogin;
import jp.co.ixit.selenide.form_view.MyPageUser;

/**
 * Selenide test case.
 * 
 * @author Okazaki
 */
@RunWith(JUnitPlatform.class)
public class testUserProfileTest {

	final static String DRIVER_PATH = System.getProperty("user.dir") + "\\chromedriver.exe";
	
	@BeforeAll
	public static void setUpClass() {
		Configuration.timeout = 10000; // タイムアウトの時間を10000ミリ秒にする(デフォルト:4000ミリ秒)
		Configuration.browser = WebDriverRunner.CHROME;
		System.setProperty("webdriver.chrome.driver", DRIVER_PATH);
	}

    @BeforeEach
    void init() {
    	
    }
	

	    @Test
	    public void 一般入試_100182() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00183@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８２", "てすと１８２","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100183() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00184@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８３", "てすと１８３","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100184() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00185@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８４", "てすと１８４","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100185() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00186@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８５", "てすと１８５","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100186() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00187@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８６", "てすと１８６","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100187() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00188@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８７", "てすと１８７","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100188() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00189@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８８", "てすと１８８","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100189() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00190@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１８９", "てすと１８９","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }

	    @Test
	    public void 一般入試_100190() {

	        MyPageLogin.でログインする("bunkyo.opt+Ippan00191@gmail.com","Test1234");
	        MyPageUser.でテストデータ入力("大学１９０", "てすと１９０","ジュケンヒョウ","テスト", "千葉県", "都道府県立", "千葉東");

	    }
	
	@AfterEach
	public void tearDown() {

	}

	@AfterAll
	public static void tearDownClass() {
		WebDriverRunner.closeWebDriver();
	}
	
}
